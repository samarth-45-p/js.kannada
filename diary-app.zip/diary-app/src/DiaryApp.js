import React, { useState } from "react";
import "./App.css";

export default function DiaryApp() {
  const [notes, setNotes] = useState([]);
  const [input, setInput] = useState("");
  const [editId, setEditId] = useState(null);

  const addOrUpdateNote = (e) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) return;

    const now = new Date().toLocaleString();

    if (editId !== null) {
      setNotes(prev =>
        prev.map(note =>
          note.id === editId
            ? { ...note, text: trimmed, edited: now }
            : note
        )
      );
      setEditId(null);
    } else {
      setNotes(prev => [
        ...prev,
        { id: Date.now(), text: trimmed, created: now, edited: now }
      ]);
    }

    setInput("");
  };

  const deleteNote = (id) => {
    setNotes(prev => prev.filter(note => note.id !== id));
  };

  const editNote = (note) => {
    setInput(note.text);
    setEditId(note.id);
  };

  return (
    <div className="diary-app">
      <header className="diary-header">
        <h1>✍️ My Diary</h1>
      </header>

      <form className="diary-form" onSubmit={addOrUpdateNote}>
        <textarea
          className="diary-textarea"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Write your thoughts..."
          rows="5"
        />
        <br />
        <button className="btn add-btn" type="submit">
          {editId !== null ? "Update Note" : "Add Note"}
        </button>
      </form>

      <ul className="diary-list">
        {notes.length === 0 && <li className="empty">No notes yet — add one!</li>}

        {notes.map((note) => (
          <li key={note.id} className="diary-item">
            <div className="diary-content">
              <p>{note.text}</p>
              <small>
                Created: {note.created} • Edited: {note.edited}
              </small>
            </div>

            <div className="diary-actions">
              <button className="btn edit-btn" onClick={() => editNote(note)}>
                Edit
              </button>
              <button className="btn delete-btn" onClick={() => deleteNote(note.id)}>
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}