import DiaryApp from "./DiaryApp";
import "./App.css";

function App() {
  return <DiaryApp />;
}

export default App;