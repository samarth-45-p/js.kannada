
# Contact Manager App

A simple React app to manage contacts with Add, Edit, and Delete features.

## How to run

1. Install dependencies:
   npm install

2. Start the app:
   npm start
