
import React, { useState } from "react";
import "./App.css";

export default function ContactApp() {
  const [contacts, setContacts] = useState([]);
  const [input, setInput] = useState({ name: "", phone: "", email: "" });
  const [editId, setEditId] = useState(null);

  const handleInputChange = (e) => {
    setInput({
      ...input,
      [e.target.name]: e.target.value,
    });
  };

  const addOrUpdateContact = (e) => {
    e.preventDefault();

    const trimmedName = input.name.trim();
    const trimmedPhone = input.phone.trim();
    const trimmedEmail = input.email.trim();

    if (!trimmedName || !trimmedPhone || !trimmedEmail) return;

    if (editId !== null) {
      setContacts((prev) =>
        prev.map((contact) =>
          contact.id === editId
            ? { ...contact, ...input }
            : contact
        )
      );
      setEditId(null);
    } else {
      setContacts((prev) => [
        ...prev,
        { id: Date.now(), ...input },
      ]);
    }

    setInput({ name: "", phone: "", email: "" });
  };

  const editContact = (contact) => {
    setInput({ name: contact.name, phone: contact.phone, email: contact.email });
    setEditId(contact.id);
  };

  const deleteContact = (id) => {
    setContacts((prev) => prev.filter((contact) => contact.id !== id));
  };

  return (
    <div className="contact-app">
      <header>
        <h1>📇 Contact Manager</h1>
      </header>

      <form onSubmit={addOrUpdateContact} className="contact-form">
        <input
          type="text"
          name="name"
          value={input.name}
          onChange={handleInputChange}
          placeholder="Full Name"
        />
        <input
          type="tel"
          name="phone"
          value={input.phone}
          onChange={handleInputChange}
          placeholder="Phone Number"
        />
        <input
          type="email"
          name="email"
          value={input.email}
          onChange={handleInputChange}
          placeholder="Email Address"
        />
        <button type="submit">
          {editId !== null ? "Update Contact" : "Add Contact"}
        </button>
      </form>

      <ul className="contact-list">
        {contacts.length === 0 && <li>No contacts yet — add one!</li>}

        {contacts.map((contact) => (
          <li key={contact.id} className="contact-item">
            <div>
              <strong>{contact.name}</strong><br />
              📞 {contact.phone}<br />
              📧 {contact.email}
            </div>

            <div className="actions">
              <button onClick={() => editContact(contact)}>Edit</button>
              <button onClick={() => deleteContact(contact.id)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
